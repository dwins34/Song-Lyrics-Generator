import "./App.css";
import Header from "./Component/Header";
import HomeScreen from "./Component/HomeScreen";

function App() {
  return (
    <div className="App">
      <Header />
      <HomeScreen />
    </div>
  );
}

export default App;
