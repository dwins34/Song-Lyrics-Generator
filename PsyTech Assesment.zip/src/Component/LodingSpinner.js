import React, { useEffect } from "react";
import "./spinner.css";

export default function LoadingSpinner() {
  useEffect(() => {
    document.body.style.overflowY = "hidden";

    // clean up function for overflowY style css
    return () => {
      document.body.style.overflowY = "scroll";
    };
  }, []);
  return (
    <div className="spinner-wrapper">
      <div className="spinner-container">
        <div className="loading-spinner"></div>
      </div>
    </div>
  );
}
