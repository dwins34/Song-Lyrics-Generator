import React, { useEffect, useRef, useState } from "react";
import GenerateChords from "./GenerateChords";
import "./homeScreen.css";
import axios from "axios";
import LoadingSpinner from "./LodingSpinner";

let valueFromGenerateChord = "";
function HomeScreen() {
  const [retrieveData, setRetrieveData] = useState("");
  const [generateChords, setGenerateChord] = useState(false);
  const [isLoding, setIsLoading] = useState(false);
  const [generateBtnClicked, setGenerateBtnClicked] = useState(false);
  const [showText, setShowText] = useState(true);
  const textAreaRef = useRef("");

  const genreRef = useRef();
  const artistsRef = useRef();
  const modifierOneRef = useRef();
  const modifierTwoRef = useRef();
  const modifierThreeRef = useRef();

  const value = (v) => {
    const valueFromChord = {
      ...v,
    };
    valueFromGenerateChord = valueFromChord;
  };

  //calling the post method when the btn is clicked
  const getResponse = () => {
    const genreValue = genreRef.current.value;
    const artistValue = artistsRef.current.value;
    const modifierOneValue = modifierOneRef.current.value;
    const modifierTwoValue = modifierTwoRef.current.value;
    const modifierThreeValue = modifierThreeRef.current.value;
    const keyValue = valueFromGenerateChord.key;
    const scaleValue = valueFromGenerateChord.scale;
    let data = null;
    // const scaleValue = value.scale;
    // console.log(keyValue + "  " + scaleValue);
    if (generateChords) {
      data = JSON.stringify({
        genre: { genreValue },
        artist: { artistValue },
        modifier1: { modifierOneValue },
        modifier2: { modifierTwoValue },
        modifier3: { modifierThreeValue },
        key: { keyValue },
        scale: { scaleValue },
      });
    } else {
      data = JSON.stringify({
        genre: { genreValue },
        artist: { artistValue },
        modifier1: { modifierOneValue },
        modifier2: { modifierTwoValue },
        modifier3: { modifierThreeValue },
      });
    }

    // Sending the post request for the raw data
    axios
      .post("https://lyrist-ai.azurewebsites.net/lyric", data, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      .then(function (response) {
        setRetrieveData(response.data.output);
        setIsLoading(false);
        setGenerateBtnClicked(false);
        console.log(response.data.output);
      })
      .catch(function (error) {
        setIsLoading(true);
        console.log(error);
      });
  };

  const generateLyricsHandler = (e) => {
    e.preventDefault();
    setGenerateBtnClicked(true);
    setIsLoading(true);

    getResponse();
  };

  //To open or close generate chords component
  const GenerateChordSwitchHandler = (e) => {
    console.log(e.target.checked);
    setGenerateChord(e.target.checked);
  };

  //copy to clipboard function
  const copyToClipboard = (e) => {
    e.preventDefault();
    document.execCommand("copy");
    textAreaRef.current.select();
    e.target.focus();
    window.alert("Text copied.");
  };

  //To make the text to share with the respect share button
  function getText() {
    let shareText = "";
    shareText += "Checkout this song I generated using:%0A";
    shareText += "https://lyrist-ai.onrender.com%0A%0A";
    shareText +=
      artistsRef.current.value + " singing " + genreRef.current.value;
    if (generateChords) {
      shareText +=
        " in " +
        valueFromGenerateChord.key +
        " " +
        valueFromGenerateChord.scale;
    }
    shareText += "%0A";
    return { shareText };
  }
  //to send lyrics to the whatsapp web
  const handleWhatsAppWeb = (e) => {
    e.preventDefault();
    let { shareText } = getText();
    if (retrieveData) {
      let data = retrieveData;
      data = data.replace(/\n/g, "%0A");
      window.open("whatsapp://send?text=" + shareText + "%0A%0A" + data);
    }
  };
  //to send lyrics to the whatsapp web
  const handleWhatsApp = (e) => {
    e.preventDefault();
    let { shareText } = getText();
    if (retrieveData) {
      let data = retrieveData;
      data = data.replace(/\n/g, "%0A");
      window.open(
        "https://web.whatsapp.com/send?text=" + shareText + "%0A%0A" + data
      );
    }
  };
  //to send lyrics to the gmail
  const handleEmail = (e) => {
    e.preventDefault();
    let { shareText } = getText();
    if (retrieveData) {
      let data = retrieveData;
      data = data.replace(/\n/g, "%0A");
      window.location.href =
        "mailto:?subject=Checkout this song generated on lyrist-ai&body=" +
        shareText +
        "%0A%0A" +
        data;
    }
  };

  //Setting all the data in text area to blank if any input changes are done
  const formOnChangeHandler = () => {
    setRetrieveData("");
    setIsLoading(false);
    setShowText(false);
  };

  //Get all the generes from the API(when needed)
  const genres = [
    "Pop",
    "Rock",
    "R&B",
    "Hip-Hop",
    "Rap",
    "Soul",
    "Blues",
    "Jazz",
    "Gospel",
    "Reggae",
    "Ska",
    "World Music",
    "Folk",
    "Country",
    "Funk",
    "R&B Soul",
    "Hip Hop Soul",
    "Neo Soul",
    "Swing",
    "Big Band",
    "Vocal Jazz",
    "Contemporary R&B",
    "Doo-Wop",
    "Soul Blues",
    "Electric Blues",
    "Chicago Blues",
    "Delta Blues",
    "Blues Rock",
    "Blues Pop",
    "Classic Rock",
    "Progressive Rock",
    "Hard Rock",
    "Soft Rock",
    "Pop Rock",
    "Folk Rock",
    "Country Rock",
    "Glam Rock",
    "Rock and Roll",
    "Rockabilly",
    "Surf Rock",
    "Psychedelic Rock",
    "New Wave",
    "Post-Punk",
    "Punk Rock",
    "Grunge",
    "Alternative Rock",
    "Indie Rock",
    "Adult Contemporary",
    "Easy Listening",
    "Opera",
    "Musical Theatre",
    "Choral Music",
    "Oratorio",
    "Art Song",
    "Lieder",
    "Gospel Music",
    "Spirituals",
    "Contemporary Christian Music",
  ];
  const artists = [
    "Kanye West",
    "Drake",
    "Ariana Grande",
    "Billie Eilish",
    "Ed Sheeran",
    "Taylor Swift",
    "Bad Bunny",
    "The Weeknd",
    "Roddy Ricch",
    "Post Malone",
    "Justin Bieber",
    "Harry Styles",
    "Lady Gaga",
    "BTS",
    "Lil Nas X",
    "Shawn Mendes",
    "Halsey",
    "Maroon 5",
    "Khalid",
    "Luke Combs",
    "Cardi B",
    "Doja Cat",
    "Bruno Mars",
    "Adele",
    "Eminem",
    "Nicki Minaj",
    "Lizzo",
    "Megan Thee Stallion",
    "Travis Scott",
    "Dua Lipa",
    "Calvin Harris",
    "Imagine Dragons",
    "The Chainsmokers",
    "Katy Perry",
    "Postmodern Jukebox",
    "Zedd",
    "Lana Del Rey",
    "Pink",
    "Queen",
    "Elton John",
    "Madonna",
    "Michael Jackson",
    "The Beatles",
    "Rolling Stones",
    "Led Zeppelin",
    "The Who",
    "U2",
    "Pink Floyd",
    "The Doors",
    "AC/DC",
    "Aerosmith",
    "Iron Maiden",
    "Metallica",
    "Guns N' Roses",
    "Black Sabbath",
    "Deep Purple",
    "Judas Priest",
    "Jimi Hendrix",
    "Eric Clapton",
    "The Rolling Stones",
    "Bee Gees",
    "Earth, Wind & Fire",
    "Whitney Houston",
    "Michael Bolton",
    "George Michael",
    "Paul Simon",
    "Elvis Presley",
    "Frank Sinatra",
    "Dean Martin",
    "Tony Bennett",
    "Ella Fitzgerald",
    "Billie Holiday",
    "Duke Ellington",
    "Miles Davis",
    "John Coltrane",
    "Charlie Parker",
    "Louis Armstrong",
    "Dizzy Gillespie",
    "Thelonious Monk",
    "Cole Porter",
    "Irving Berlin",
    "George Gershwin",
    "Rodgers and Hammerstein",
  ];

  return (
    <div className={"homeScreen"}>
      <h1>Create your own lyrics.</h1>
      <div className="homeScreen__content">
        <form className="homeScreen__form">
          <div className="homeScreen__formInline">
            <label className="homeScreen__genre">Genre:</label>
            <select
              defaultValue="none"
              className="homeScreen__genreSelect"
              ref={genreRef}
              onClick={formOnChangeHandler}
            >
              {genres.map((genre) => (
                <option key={genre}>{genre}</option>
              ))}
            </select>
          </div>
          <div className="homeScreen__formInline">
            <label className="homeScreen__genre">Artist:</label>
            <select
              className="homeScreen__genreSelect"
              defaultValue="none"
              ref={artistsRef}
              onClick={formOnChangeHandler}
            >
              {artists.map((artist) => (
                <option key={artist}>{artist}</option>
              ))}
            </select>
          </div>
          <div className="homeScreen__formInline">
            <label className="homeScreen__genre">Modifier 1:</label>
            <input
              className="homeScreen__genreSelect"
              title="Add a modifier (optional). Good modifiers can be anything ranging from object, animals, places, moods, etc. "
              type="text"
              id="modifier1"
              placeholder="Eg. - mood type like happy"
              ref={modifierOneRef}
              onClick={formOnChangeHandler}
            />
          </div>
          <div className="homeScreen__formInline">
            <label className="homeScreen__genre">Modifier 2:</label>
            <input
              className="homeScreen__genreSelect"
              title="Add another modifier (optional). Good modifiers can be anything ranging from object, animals, places, moods, etc. "
              type="text"
              id="modifier2"
              placeholder="Eg. - some object like pringles"
              ref={modifierTwoRef}
              onClick={formOnChangeHandler}
            />
          </div>
          <div className="homeScreen__formInline">
            <label className="homeScreen__genre">Modifier 3:</label>
            <input
              className="homeScreen__genreSelect"
              title="Add a third modifier (optional). Good modifiers can be anything ranging from object, animals, places, moods, etc. "
              type="text"
              id="modifier3"
              placeholder="Eg. - topic like politics "
              ref={modifierThreeRef}
              onClick={formOnChangeHandler}
            />
          </div>
          <div className="homeScreen__formInline width_to_center">
            <label className="homeScreen__genre generate_lyrics">
              {" "}
              Generate chords for lyrics:{" "}
            </label>
            <label className="switch">
              <input
                onChange={GenerateChordSwitchHandler}
                id="GenerateChordSwitch"
                type="checkbox"
                value={generateChords}
              />
              <span className="slider "></span>
            </label>
          </div>
          {generateChords && <GenerateChords getValue={value} />}
          <button
            onClick={generateLyricsHandler}
            className="generate_lyrics__button"
          >
            Generate Lyrics
          </button>
          <label
            style={{
              fontSize: "1.2rem",
              width: "24%",
              color: "yellow",
              backgroundColor: "#614b96",
              marginTop: "14px",
            }}
          >
            Generated Lyrics:
          </label>
          {generateBtnClicked && isLoding && <LoadingSpinner />}

          <textarea
            id="HomeScreen__textArea"
            ref={textAreaRef}
            className="textArea"
            defaultValue={`${showText || !isLoding ? retrieveData : ""}`}
          />

          <button className="generate_lyrics__button" onClick={copyToClipboard}>
            Copy Lyrics
          </button>
          <label
            style={{
              fontSize: "1.2rem",
              width: "24%",
              color: "yellow",
              backgroundColor: "#614b96",
              marginTop: "14px",
            }}
          >
            Share Lyrics:
            <div className="shareBtnDiv">
              <button className="shareBtn" onClick={handleWhatsApp}>
                Whatsapp
              </button>
              <button className="shareBtn" onClick={handleWhatsAppWeb}>
                Whatsapp Web
              </button>
              <button className="shareBtn" onClick={handleEmail}>
                Gmail
              </button>
            </div>
          </label>
        </form>
      </div>
    </div>
  );
}

export default HomeScreen;
