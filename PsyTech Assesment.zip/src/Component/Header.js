import React, { useEffect, useState } from "react";
import "./header.css";
function Header() {
  const [show, handleShow] = useState(false);

  const transitionShow = () => {
    if (window.scrollY > 100) {
      handleShow(true);
    } else {
      handleShow(false);
    }
  };
  useEffect(() => {
    window.addEventListener("scroll", transitionShow);
    return () => window.removeEventListener("scroll", transitionShow);
  }, []);
  return (
    <nav className={`header ${show && "header__backgroundColor"}`}>
      <div className="header__content">
        <img
          className="header__logo"
          src="https://psytech.ai/assets/images/image01.png?v=c4e0f564"
          alt="logo"
        />
        <button className="header__button">Sign In</button>
      </div>
    </nav>
  );
}

export default Header;
