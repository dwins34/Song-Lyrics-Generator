import React, { useEffect, useRef } from "react";
import "./homeScreen.css";
import "./generateChord.css";

function GenerateChords(props) {
  const keys = [
    "C",
    "Db",
    "Eb",
    "E",
    "F",
    "D",
    "Gb",
    "G",
    "Ab",
    "A",
    "Bb",
    "B",
  ];
  const scaleTypes = [
    "Major",
    "Minor",
    "Dorian",
    "Phrygian",
    "Mixolydian",
    "Melodic Minor",
    "Harmonic Minor",
    "Ukranian Dorian",
  ];
  const keyRef = useRef();
  const scaleRef = useRef();

  useEffect(() => {
    const keyValue = keyRef.current.value;
    const scaleValue = scaleRef.current.value;
    const chordValue = {
      key: keyValue,
      scale: scaleValue,
    };

    props.getValue(chordValue);
  }, [keyRef, scaleRef, props]);

  return (
    <section className="generateChord__form">
      <div className="homeScreen__formInline">
        <label className="homeScreen__genre">Key:</label>
        <select className="homeScreen__genreSelect" ref={keyRef}>
          {keys.map((k) => (
            <option key={k}>{k}</option>
          ))}
        </select>
      </div>
      <div className="homeScreen__formInline">
        <label className="homeScreen__genre">Scale Type:</label>
        <select className="homeScreen__genreSelect" ref={scaleRef}>
          {scaleTypes.map((scaleType) => (
            <option key={scaleRef}>{scaleType}</option>
          ))}
        </select>
      </div>
    </section>
  );
}

export default GenerateChords;
